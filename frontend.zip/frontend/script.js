document.getElementById("enter-btn").addEventListener("click", () => {
    alert("Button clicked! You can navigate to the login page later.");
});
